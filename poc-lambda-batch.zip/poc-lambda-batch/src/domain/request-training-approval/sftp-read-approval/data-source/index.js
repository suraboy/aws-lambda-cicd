const ReceiveEmployeeList = require("./receive_employee_list");

module.exports = {
    ReceiveEmployeeList,
}