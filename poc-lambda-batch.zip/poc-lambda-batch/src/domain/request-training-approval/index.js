const SFTPReadApproval = require("./sftp-read-approval");
const SFTPWriteApproval = require("./sftp-write-approval");

module.exports = {
    SFTPReadApproval,
    SFTPWriteApproval
}