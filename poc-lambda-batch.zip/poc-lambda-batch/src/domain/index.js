const RequestTrainingApproval = require("./request-training-approval");
module.exports = {
    RequestTrainingApproval
}